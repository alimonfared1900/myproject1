<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::get('/', function () {
    return view('welcome');
});
*/

Route::get('/', 'PeopleController@people');
Route::get('people', 'PeopleController@people');
Route::post('people', ['as'=>'people.store','uses'=>'PeopleController@peoplePost']);

/*
Route::get('listpeople', function () {
$people = DB::table('people')->get();
return view('listpeople', ['people' => $people]);});
*/
Route::get('listpeople', 'PeopleController@listpeople');
Route::post('listpeople', ['as'=>'people.list','uses'=>'PeopleController@listpeople']);



