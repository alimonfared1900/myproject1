<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class People extends Model
{
	public $table = 'people';

	public $fillable = ['user_number','name','fname','job','address'];
}
