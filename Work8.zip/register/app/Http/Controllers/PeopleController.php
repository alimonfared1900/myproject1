<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\People;

class PeopleController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	 
    public function people()
    {
        return view('people');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function PeoplePost(Request $request)
    {
        $this->validate($request, [
        		'user_number' => 'required',
				'name' => 'required',
				'fname' => 'required',
        		'job' => 'required',
        		'address' => 'required'
        	]);
        People::create($request->all());
        return back()->with('success', 'تشکر بابت ثبت اطلاعات');
    }
	
    public function listpeople(Request $request)
    {
		$user_number = @$_GET['user_number'];
		//$items = People::where([ ['user_number', 'LIKE', '%' . $user_number . '%']])->get();
		$items = People::where([ ['user_number', '=',  $user_number ]])->get();
		return view('listpeople', compact('items'));
    }
	
}
