<!DOCTYPE html>

<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<title>ثبت اطلاعات</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<style>
	body
	{
		font-family:tahoma;
		font-size:9pt;
	}
	
	.form-control
	{
		width:300px;
	}
	</style>
	
</head>

<body style='direction:rtl'>


<div class="container">
	<br /><br />
	
	<table style='margin:auto; border:black solid 1px; width:300px; text-align:center;'>
		<tr>
			<td style='width:50%;'>
				<a href="{{ route('people.store') }}">ثبت اطلاعات</a>
			</td>
			<td style='width:50%;'>
				<a href="{{ route('people.list') }}">جستجو</a>
			</td>
		</tr>
	</table>

	<br />
	<h3>فرم ثبت اطلاعات</h3>
	<br />

	@if(Session::has('success'))

	    <div class="alert alert-success">

	      {{ Session::get('success') }}

	    </div>

	@endif


	{!! Form::open(['route'=>'people.store']) !!}


		<div class="form-group {{ $errors->has('user_number') ? 'has-error' : '' }}">

			{!! Form::label('شماره کاربری:') !!}

			{!! Form::number('user_number', old('user_number'), ['class'=>'form-control', 'placeholder'=>'ورود شماره کاربری']) !!}

			<span class="text-danger">{{ $errors->first('user_number') }}</span>

		</div>
		
		<div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">

			{!! Form::label('نام:') !!}

			{!! Form::text('name', old('name'), ['class'=>'form-control', 'placeholder'=>'ورود نام']) !!}

			<span class="text-danger">{{ $errors->first('name') }}</span>

		</div>
		
		<div class="form-group {{ $errors->has('fname') ? 'has-error' : '' }}">

			{!! Form::label('نام خانوادگی:') !!}

			{!! Form::text('fname', old('fname'), ['class'=>'form-control', 'placeholder'=>'ورود نام خانوادگی']) !!}

			<span class="text-danger">{{ $errors->first('fname') }}</span>

		</div>


		<div class="form-group {{ $errors->has('job') ? 'has-error' : '' }}">

			{!! Form::label('شغل:') !!}

			{!! Form::text('job', old('job'), ['class'=>'form-control', 'placeholder'=>'ورود شغل']) !!}

			<span class="text-danger">{{ $errors->first('job') }}</span>

		</div>


		<div class="form-group {{ $errors->has('address') ? 'has-error' : '' }}">

			{!! Form::label('آدرس:') !!}

			{!! Form::textarea('address', old('address'), ['class'=>'form-control', 'placeholder'=>'ورود آدرس']) !!}

			<span class="text-danger">{{ $errors->first('address') }}</span>

		</div>


		<div class="form-group">

			<button class="btn btn-success">ثبت اطلاعات</button>

		</div>


	{!! Form::close() !!}


</div>

</body>

</html>