<!DOCTYPE html>

<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<title>ثبت اطلاعات</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<style>
	body
	{
		font-family:tahoma;
		font-size:9pt;
	}
	
	.form-control
	{
		width:300px;
	}
	</style>
	
</head>

<body style='direction:rtl'>


<div class="container">
	<br /><br />
	
	<table style='margin:auto; border:black solid 1px; width:300px; text-align:center;'>
		<tr>
			<td style='width:50%;'>
				<a href="<?php echo e(route('people.store')); ?>">ثبت اطلاعات</a>
			</td>
			<td style='width:50%;'>
				<a href="<?php echo e(route('people.list')); ?>">جستجو</a>
			</td>
		</tr>
	</table>

	<br />
	<h3>فرم ثبت اطلاعات</h3>
	<br />

	<?php if(Session::has('success')): ?>

	    <div class="alert alert-success">

	      <?php echo e(Session::get('success')); ?>


	    </div>

	<?php endif; ?>


	<?php echo Form::open(['route'=>'people.store']); ?>



		<div class="form-group <?php echo e($errors->has('user_number') ? 'has-error' : ''); ?>">

			<?php echo Form::label('شماره کاربری:'); ?>


			<?php echo Form::number('user_number', old('user_number'), ['class'=>'form-control', 'placeholder'=>'ورود شماره کاربری']); ?>


			<span class="text-danger"><?php echo e($errors->first('user_number')); ?></span>

		</div>
		
		<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">

			<?php echo Form::label('نام:'); ?>


			<?php echo Form::text('name', old('name'), ['class'=>'form-control', 'placeholder'=>'ورود نام']); ?>


			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>

		</div>
		
		<div class="form-group <?php echo e($errors->has('fname') ? 'has-error' : ''); ?>">

			<?php echo Form::label('نام خانوادگی:'); ?>


			<?php echo Form::text('fname', old('fname'), ['class'=>'form-control', 'placeholder'=>'ورود نام خانوادگی']); ?>


			<span class="text-danger"><?php echo e($errors->first('fname')); ?></span>

		</div>


		<div class="form-group <?php echo e($errors->has('job') ? 'has-error' : ''); ?>">

			<?php echo Form::label('شغل:'); ?>


			<?php echo Form::text('job', old('job'), ['class'=>'form-control', 'placeholder'=>'ورود شغل']); ?>


			<span class="text-danger"><?php echo e($errors->first('job')); ?></span>

		</div>


		<div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">

			<?php echo Form::label('آدرس:'); ?>


			<?php echo Form::textarea('address', old('address'), ['class'=>'form-control', 'placeholder'=>'ورود آدرس']); ?>


			<span class="text-danger"><?php echo e($errors->first('address')); ?></span>

		</div>


		<div class="form-group">

			<button class="btn btn-success">ثبت اطلاعات</button>

		</div>


	<?php echo Form::close(); ?>



</div>

</body>

</html>