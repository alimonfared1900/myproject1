<!DOCTYPE html>

<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<title>جستجو اطلاعات</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	
	<style>
	body
	{
		font-family:tahoma;
		font-size:9pt;
	}
	
	.form-control
	{
		width:300px;
	}
	</style>
	
</head>

<body style='direction:rtl'>

	<br /><br />
	
	<table style='margin:auto; border:black solid 1px; width:300px; text-align:center;'>
		<tr>
			<td style='width:50%;'>
				<a href="<?php echo e(route('people.store')); ?>">ثبت اطلاعات</a>
			</td>
			<td style='width:50%;'>
				<a href="<?php echo e(route('people.list')); ?>">جستجو</a>
			</td>
		</tr>
	</table>

	<br />
	<h3>جستجو براساس شماره کاربری</h3>
	<br />

<table style='margin:auto; width:230px;'>
	<tr>
		<td>
			<form action="" method="GET">
				<input name="user_number" placeholder="شماره کاربری">
				<button>جستجو</button>
			</form>
		</td>
	</tr>
</table>
		
<div class="container">

<table style='width:500px; margin:auto;border:red solid 1px; margin-top:100px; text-align:center;'>
    <tr>    
      <td>شماره کاربری</td> 
	  <td>نام</td>
	  <td>نام خانوادگی</td>
	  <td>شغل</td>
	  <td>آدرس</td>
    </tr>
	
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>    
      <td><?php echo e($data->user_number); ?></td>
      <td><?php echo e($data->name); ?></td>             
	  <td><?php echo e($data->fname); ?></td>   
	  <td><?php echo e($data->job); ?></td>   
	  <td><?php echo e($data->address); ?></td>   
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
</div>

</body>

</html>